#pragma once
#define SFML_STATIC 1
#define _CRT_SECURE_NO_WARNINGS
#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <iostream>
#include <unordered_map>
#include <Windows.h>
#include <locale>
#include <codecvt>
#include <chrono>
#include <fstream>
#include <array>
#include <queue>
#include <vector>

using namespace std;

#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "winmm.lib")
#pragma comment (lib, "ws2_32.lib")